--I am the bone of my noteskin
--Arrows are my body, and explosions are my blood
--I have created over a thousand noteskins
--Unknown to death
--Nor known to life
--Have withstood pain to create many noteskins
--Yet these hands will never hold anything
--So as I pray, Unlimited Stepman Works

return {
	notes= "notes.lua",
	layers= {"receptors.lua", "explosions.lua"},
	supports_all_buttons= false,
	buttons= {"Left", "Down", "Up", "Right"},
	fallback= "",
	skin_parameters= {},
	skin_parameter_info= {},
}
